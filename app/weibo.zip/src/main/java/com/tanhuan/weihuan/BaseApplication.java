package com.tanhuan.weihuan;

import android.app.Application;

/**
 * Created by chenYaNing on 2017/11/28.
 */

public class BaseApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        //执行一些初始化操作

    }
}
