package com.tanhuan.weihuan.constants;

/**
 * Created by chenYaNing on 2017/11/28.
 */

public class CommonConstants {

    public static final String SP_NAME = "sp";

    public static final boolean isShowLog = false;

}
